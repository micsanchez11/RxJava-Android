package packt.reactivestocks.yahoo.json;

import java.util.List;

public class YahooStockResults {
    private List<YahooStockQuote> quote;

    public List<YahooStockQuote> getQuote() {
        return quote;
    }
}
